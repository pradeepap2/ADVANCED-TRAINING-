package Project_8;

public abstract class Instrument {
	public abstract void play();
}
